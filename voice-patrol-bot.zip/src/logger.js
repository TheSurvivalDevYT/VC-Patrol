const { EmbedBuilder } = require('discord.js');

/**
 * Send a moderation log embed to the configured channel.
 * Ensures we only send once per detection call (callers control dedupe per clip).
 */
async function sendLog({ client, logChannelId, guild, voiceChannel, user, matchedWord, transcript, engineName }) {
  try {
    const channel = await client.channels.fetch(logChannelId);
    if (!channel) return;
    const embed = new EmbedBuilder()
      .setTitle('Voice Automod: Badword Detected')
      .setColor(0xff5555)
      .addFields(
        { name: 'User', value: `${user.tag} (${user.id})`, inline: false },
        { name: 'Voice Channel', value: `${voiceChannel?.name || 'Unknown'} (${voiceChannel?.id})`, inline: false },
        { name: 'Matched Word', value: `\`${matchedWord}\`` },
        { name: 'Transcript Snippet', value: transcript ? `“${transcript.slice(0, 256)}”` : '(empty)' }
      )
      .setFooter({ text: `Engine: ${engineName} • Guild: ${guild?.name || 'N/A'} (${guild?.id}) • Bot: ${client.user?.tag}` })
      .setTimestamp(new Date());
    await channel.send({ embeds: [embed] });
  } catch (e) {
    console.error('Failed to send log embed:', e);
  }
}

module.exports = { sendLog };

const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Partials, Events } = require('discord.js');
const { VoicePatrol } = require('./voicePatrol');

const configPath = path.join(__dirname, '..', 'config.json');
let cfg;
try {
  cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
} catch (e) {
  console.error('Failed to read config.json. Copy config.example.json -> config.json and fill values.');
  process.exit(1);
}

const REQUIRED_INTENTS = [
  GatewayIntentBits.Guilds,
  GatewayIntentBits.GuildVoiceStates
];

function makeClient(botCfg, idx) {
  const client = new Client({
    intents: REQUIRED_INTENTS,
    partials: [Partials.GuildMember, Partials.Channel, Partials.User]
  });

  const shardName = `bot#${idx+1}`;
  const patrol = new VoicePatrol(client, {
    logChannelId: cfg.logChannelId,
    clipSeconds: cfg.clipSeconds,
    engine: cfg.engine,
    whisper: cfg.whisper
  }, shardName);

  client.once(Events.ClientReady, async () => {
    console.log(`[${shardName}] Logged in as ${client.user.tag}`);
    await patrol.join(botCfg.guildId, botCfg.voiceChannelId);
  });

  client.on('error', (e) => console.error(`[${shardName}] Client error:`, e));
  client.on('shardError', (e) => console.error(`[${shardName}] Shard error:`, e));

  client.login(botCfg.token).catch(err => {
    console.error(`[${shardName}] Login failed:`, err.message);
  });

  return client;
}

if (!Array.isArray(cfg.bots) || !cfg.bots.length) {
  console.error('config.json must include a "bots" array with at least one bot entry.');
  process.exit(1);
}

const clients = cfg.bots.map((botCfg, i) => makeClient(botCfg, i));

process.on('SIGINT', () => {
  console.log('Shutting down...');
  clients.forEach(c => c.destroy());
  process.exit(0);
});

const wav = require('wav');

/**
 * Convert raw PCM Int16LE buffer (mono, 48kHz) into a WAV Buffer.
 * @param {Buffer} pcmBuffer - raw PCM (signed 16-bit LE), 48kHz, mono
 * @param {number} sampleRate - default 48000
 * @returns {Promise<Buffer>}
 */
function pcmToWavBuffer(pcmBuffer, sampleRate = 48000) {
  return new Promise((resolve, reject) => {
    try {
      const writer = new wav.Writer({
        channels: 1,
        sampleRate,
        bitDepth: 16
      });
      const chunks = [];
      writer.on('data', (d) => chunks.push(d));
      writer.on('finish', () => resolve(Buffer.concat(chunks)));
      writer.end(pcmBuffer);
    } catch (e) {
      reject(e);
    }
  });
}

module.exports = { pcmToWavBuffer };

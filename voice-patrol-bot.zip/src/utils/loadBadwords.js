const fs = require('fs');
const path = require('path');

function loadBadwords() {
  const p = path.join(__dirname, '../../data/badwords.txt');
  if (!fs.existsSync(p)) return [];
  const lines = fs.readFileSync(p, 'utf8')
    .split(/\r?\n/)
    .map(l => l.trim())
    .filter(Boolean);
  // Build a case-insensitive regex array
  // We escape regex metacharacters so words are literal matches (also within longer words).
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const patterns = lines.map(w => new RegExp(esc(w), 'i'));
  return { words: lines, patterns };
}

module.exports = { loadBadwords };

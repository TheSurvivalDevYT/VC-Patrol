const { joinVoiceChannel, getVoiceConnection, EndBehaviorType, VoiceConnectionStatus, entersState } = require('@discordjs/voice');
const prism = require('prism-media');
const { loadBadwords } = require('./utils/loadBadwords');
const { sendLog } = require('./logger');
const { transcribePCM } = require('./stt/whisper');

/**
 * VoicePatrol handles joining a VC and recording user audio into clips,
 * transcribing, and scanning against badwords.
 */
class VoicePatrol {
  constructor(client, cfg, shardName) {
    this.client = client;
    this.cfg = cfg;
    this.shardName = shardName || client.user?.tag || 'bot';
    const { words, patterns } = loadBadwords();
    this.badwords = words;
    this.patterns = patterns;
    this.clipMs = Math.max(1000, Math.floor((cfg.clipSeconds || 5) * 1000));
    this.engine = cfg.engine || 'whisper';
    this.whisperCfg = cfg.whisper || {};
    this.userBuffers = new Map(); // userId -> { buffers: Buffer[], timer: NodeJS.Timeout }
  }

  async join(guildId, voiceChannelId) {
    const channel = await this.client.channels.fetch(voiceChannelId).catch(() => null);
    if (!channel || channel.type !== 2) { // 2 = GuildVoice
      console.error(`[${this.shardName}] Voice channel invalid: ${voiceChannelId}`);
      return;
    }
    const connection = joinVoiceChannel({
      channelId: voiceChannelId,
      guildId,
      adapterCreator: channel.guild.voiceAdapterCreator,
      selfDeaf: false, // we need to receive audio
      selfMute: true
    });

    try {
      await entersState(connection, VoiceConnectionStatus.Ready, 20_000);
      console.log(`[${this.shardName}] Joined VC ${channel.name} (${voiceChannelId})`);
      this.startReceiving(connection, channel);
    } catch (e) {
      console.error(`[${this.shardName}] Failed to join VC:`, e);
    }
  }

  startReceiving(connection, voiceChannel) {
    const receiver = connection.receiver;

    receiver.speaking.on('start', (userId) => {
      // Subscribe to Opus stream for this user
      const opusStream = receiver.subscribe(userId, { end: { behavior: EndBehaviorType.AfterSilence, duration: this.clipMs } });
      const decoder = new prism.opus.Decoder({ rate: 48000, channels: 1, frameSize: 960 });
      const pcmStream = opusStream.pipe(decoder);

      let chunks = [];
      pcmStream.on('data', (d) => chunks.push(d));
      pcmStream.once('end', () => {
        if (!chunks.length) return;
        const pcmBuffer = Buffer.concat(chunks);
        this.handleClip({
          guild: voiceChannel.guild,
          voiceChannel,
          userId,
          pcmBuffer
        });
      });
    });
  }

  async handleClip({ guild, voiceChannel, userId, pcmBuffer }) {
    try {
      const user = await this.client.users.fetch(userId).catch(() => null);
      if (!user) return;

      let transcript = '';
      if (this.engine === 'whisper') {
        transcript = await transcribePCM(pcmBuffer, {
          apiKey: process.env.OPENAI_API_KEY,
          model: this.whisperCfg.model || 'gpt-4o-transcribe',
          endpoint: this.whisperCfg.endpoint || 'https://api.openai.com/v1/audio/transcriptions'
        });
      } else {
        // Placeholder for other engines (e.g., Vosk). Implement as needed.
        transcript = '';
      }

      if (!transcript || !transcript.trim()) return;

      // Match against badwords
      const match = this.patterns.find(rx => rx.test(transcript));
      if (!match) return;

      const matchedWord = this.badwords.find(w => new RegExp(w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i').test(transcript)) || '(unknown)';
      await sendLog({
        client: this.client,
        logChannelId: this.cfg.logChannelId,
        guild,
        voiceChannel,
        user,
        matchedWord,
        transcript,
        engineName: this.engine
      });
    } catch (e) {
      console.error(`[${this.shardName}] handleClip error:`, e.message);
    }
  }
}

module.exports = { VoicePatrol };

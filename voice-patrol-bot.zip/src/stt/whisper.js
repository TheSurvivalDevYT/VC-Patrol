const { pcmToWavBuffer } = require('../utils/wav');
const { request } = require('undici'); // Node 18+

/**
 * Transcribe a PCM buffer via OpenAI Whisper endpoint.
 * @param {Buffer} pcmBuffer - Int16LE PCM (mono 48kHz)
 * @param {object} opts - { apiKey, model, endpoint }
 * @returns {Promise<string>} transcript text
 */
async function transcribePCM(pcmBuffer, opts) {
  const { apiKey, model = 'gpt-4o-transcribe', endpoint = 'https://api.openai.com/v1/audio/transcriptions' } = opts || {};
  if (!apiKey) throw new Error('OPENAI_API_KEY missing for Whisper transcription.');

  const wavBuffer = await pcmToWavBuffer(pcmBuffer, 48000);

  // multipart/form-data without extra deps: construct by hand
  const boundary = '----voicepatrol' + Math.random().toString(16).slice(2);
  const CRLF = '\r\n';
  const parts = [];

  const pushField = (name, value) => {
    parts.push(Buffer.from(`--${boundary}${CRLF}`));
    parts.push(Buffer.from(`Content-Disposition: form-data; name="${name}"${CRLF}${CRLF}`));
    parts.push(Buffer.from(String(value)));
    parts.push(Buffer.from(CRLF));
  };

  const pushFile = (name, filename, mime, buf) => {
    parts.push(Buffer.from(`--${boundary}${CRLF}`));
    parts.push(Buffer.from(`Content-Disposition: form-data; name="${name}"; filename="${filename}"${CRLF}`));
    parts.push(Buffer.from(`Content-Type: ${mime}${CRLF}${CRLF}`));
    parts.push(buf);
    parts.push(Buffer.from(CRLF));
  };

  pushField('model', model);
  pushFile('file', 'clip.wav', 'audio/wav', wavBuffer);
  parts.push(Buffer.from(`--${boundary}--${CRLF}`));

  const body = Buffer.concat(parts);

  const res = await request(endpoint, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': `multipart/form-data; boundary=${boundary}`
    },
    body
  });

  const text = await res.body.text();
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error(`Whisper non-JSON response: ${text.slice(0, 200)}`);
  }
  if (data.error) throw new Error(`Whisper error: ${data.error.message || JSON.stringify(data.error)}`);
  // Both "text" and "result" formats exist; support common "text"
  return data.text || (data.results && data.results.map(r => r.alternatives?.[0]?.transcript).join(' ')) || '';
}

module.exports = {
  transcribePCM
};
